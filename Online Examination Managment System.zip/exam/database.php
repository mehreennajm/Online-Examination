<?php
		$db_host = 'localhost';
		$db_name = 'examination';
		$db_user = 'root';
		$db_password= '';


//create mysqli object
		$mysqli = new mysqli($db_host,$db_user,$db_password,$db_name);


// Error handler
		if($mysqli->connect_error){
			printf('connection failed:%s\n',$mysqli->connect_error);
			exit();
		}


?>