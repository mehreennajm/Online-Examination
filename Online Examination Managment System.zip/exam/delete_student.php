<?php


session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");


?>
<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn =  mysqli_connect($dbhost, $dbuser, $dbpass,"examination");
if(! $conn )
{
  die('Could not connect: ' .  mysqli_error());
}



if(isset($_GET['id'])){
	$id=$_GET['id'];

	$delete="DELETE FROM stdprofile where student_id='$id'";
	$show= mysqli_query($conn,$delete);
	if($show){

		header('location:panel.php?delete=true');
		}

		else
		
	header('location:panel.php?delete=false');
}

 ?>




