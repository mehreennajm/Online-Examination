<?php


session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");


?>
<?php 
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn =  mysqli_connect($dbhost, $dbuser, $dbpass,"examination");
if(! $conn )
{
  die('Could not connect: ' .  mysqli_error());
}

 

if(isset($_GET['id'])){
  $b=$_GET['id'];
  $test="select subname from subjects where s_id='$b'";
  $show= mysqli_query($conn,$test);
  $na= mysqli_fetch_assoc($show);
  }

?>

<?php 
$msg ="";
if(isset($_POST['submit'])){
   
    $dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn =  mysqli_connect($dbhost, $dbuser, $dbpass,"examination");
   

   
    $question = $_POST['subname'];
   
    
   $sql = "update subjects set subname = '$question'
   
    where s_id='$b'
   ";
    $r =  mysqli_query($conn,$sql);

    if($r){
    $msg= "<div class='alert alert-success'>Successfully Updated!</div>";

    }

    else
    $msg="<div class='alert alert-danger'>Something went wrong please try again!</div>";
    
}


?>



<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <link rel="icon" href="icon/favicon.ico">
    <link rel="shortcut icon" href="icon/favicon.ico" />  
      <style type="text/css">
        label{
          color:white;
        }
      </style>
    	
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>EDIT QUESTION</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/roboto-webfont.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
        <link href="fileinput/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="fileinput/themes/explorer-fa/theme.css" media="all" rel="stylesheet" type="text/css"/>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="fileinput/js/plugins/sortable.js" type="text/javascript"></script>
    <script src="fileinput/js/fileinput.js" type="text/javascript"></script>
    <script src="fileinput/js/locales/fr.js" type="text/javascript"></script>
    <script src="fileinput/js/locales/es.js" type="text/javascript"></script>
    <script src="fileinput/themes/explorer-fa/theme.js" type="text/javascript"></script>
    <script src="fileinput/themes/fa/theme.js" type="text/javascript"></script>

    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <!-- Sections -->
        

        
        <!--Home page style-->
        <header id="home" class="home1">
            <div class="overlay-fluid-block">
                <div class="container text-center">
                    <div class="row">
                        <div class="home-wrapper">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="home-content">
                                  <form action="" method="post">
    
   
   <div class="form-group">
    <label for="exampleInputEmail1">Subject Name:</label>
    <input type="text" name="subname" class="form-control" id="exampleInputEmail1" placeholder="Answer"
    value="<?php echo $na['subname']; ?>" >
  </div>

   

        <div class="form-group">
        <input type="submit" name="submit" class="btn btn-primary " value="Update">
       
        
        <a href="display_subjects.php" class="btn btn-success ">Back to Main Page</a>

        </div>

        <div class="form-group">
        <?php  echo $msg; ?>

        </div>


        

   
    </form>


</div></div>
                        </div>
                    </div>
                </div>			
            </div>
        </header>

      <section id="social" class="social">
            <div class="container">
                <!-- Example row of columns -->
                <div class="row">
                    <div class="social-wrapper">
                        <div class="col-md-6">
                            <div class="social-icon">
                                <a href="https://www.facebook.com" target="_blank"><i class="fa fa-facebook"></i></a>
                                <a href="https://www.twitter.com" target="_blank" ><i class="fa fa-twitter"></i></a>
                                <a href="https://www.googleplus.com" target="_blank"><i class="fa fa-google-plus"></i></a>
                                <a href="https://wwww.linkedin.com" target="_blank"><i class="fa fa-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="social-contact">
                                <a href="#"><i class="fa fa-phone"></i>+93783873895</a>
                                <a href="#"><i class="fa fa-envelope"></i>massiekhan@gmail.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- /container -->       
        </section>
		
		<div class="scrollup">
			<a href="#"><i class="fa fa-chevron-up"></i></a>
		</div>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/modernizr.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>
