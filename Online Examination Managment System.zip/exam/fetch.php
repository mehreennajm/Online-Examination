<?php
		
session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");

$output = '';

if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
$value = $_POST['search'];

	$sql = "SELECT * FROM stdprofile  where (student_id  LIKE '%$value%' or first_name LIKE '%$value%' or last_name like '%$value%') ";
	$result = mysqli_query($conn,$sql);

		if(mysqli_num_rows($result)> 0){

			$output .= '<h4 align="center"> Search Result:</h4>';
			$output .= '<div class="table-responsive">
							<table class="table table-bordered">
									<tr>
											<td>StudentID:</td>
											<td>FullName:</td>
											<td>Father Name:</td>
											<td>Gender:</td>
											<td>DOB:</td>
											<td>Address:</td>
											<td>Phone:</td>
											<td>Tazkira#:</td>
											<td>Email:</td>
											<td>Password:</td>
											<td>Urgent Files:</td>



										</tr>';

										while ($row = Mysqli_fetch_array($result)) {
											
												$output .= '	
															<tr>
															<td>'.$row['student_id'].'</td>
															<td>'.$row['first_name'].'  ' . $row['last_name'].'</td>
															<td>'.$row['fathername'].'</td>
															<td>'.$row['gender'].'</td>
															<td>'.$row['dob'].'</td>
															<td>'.$row['address'].'</td>
															<td>'.$row['phone'].'</td>
															<td>'.$row['tazkira'].'</td>
															<td>'.$row['email'].'</td>
															<td>'.$row['password'].'</td>
															<td>'.$row['urgentFiles'].'</td>
															
	
															</tr>
															';

												
										}
											echo $output;


			


		}
		else{
			echo "Data Not Found";
		}

?>


