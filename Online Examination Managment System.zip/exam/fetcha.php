<?php
		
session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");

$output = '';

if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
$value = $_POST['search'];

	$sql = "SELECT a.id,q.question,a.text,a.is_correct from questions q JOIN answers a ON 
																		a.question_id = q.id   where (question like '%$value%' or a.id like '%$value%' or text like '%$value%')";
	$result = mysqli_query($conn,$sql);

		if(mysqli_num_rows($result)> 0){

			$output .= '<h4 align="center"> Search Result:</h4>';
			$output .= '<div class="table-responsive">
							<table class="table table-bordered">
									<tr>
											<td>Answer Number:</td>
											<td>Question:</td>
											<td>T/F:</td>
											
											
											
											<td>Answers:</td>
											



										</tr>';

										while ($row = Mysqli_fetch_array($result)) {
											
												$output .= '	
															<tr>
															<td>'.$row['id'].'</td>
															<td>'.$row['question'].'</td>
															<td>'.$row['is_correct'].'</td>
															
															
															<td>'.$row['text'].'</td>
															
															
	
															</tr>
															';

												
										}
											echo $output;


			


		}
		else{
			echo "Data Not Found";
		}

?>


