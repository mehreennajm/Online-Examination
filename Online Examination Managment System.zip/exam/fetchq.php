<?php
		
session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");

$output = '';

if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
$value = $_POST['search'];

	$sql = "SELECT q.id,q.question,a.text,a.is_correct,s.subname from questions q JOIN subjects s ON 
																		q.subject_id = s.s_id  JOIN answers a on q.id=a.question_id where question like '%$value%' or q.id like '%$value%' and is_correct =1";
	$result = mysqli_query($conn,$sql);

		if(mysqli_num_rows($result)> 0){

			$output .= '<h4 align="center"> Search Result:</h4>';
			$output .= '<div class="table-responsive">
							<table class="table table-bordered">
									<tr>
											<td>ID:</td>
											<td>Question:</td>
											<td>Correct Answer:</td>
											
											
											
											<td>Subject Name:</td>
											



										</tr>';

										while ($row = Mysqli_fetch_array($result)) {
											
												$output .= '	
															<tr>
															<td>'.$row['id'].'</td>
															<td>'.$row['question'].'</td>
															<td>'.$row['text'].'</td>
															
															
															<td>'.$row['subname'].'</td>
															
															
	
															</tr>
															';

												
										}
											echo $output;


			


		}
		else{
			echo "Data Not Found";
		}

?>


