<?php
		
session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");

$output = '';

if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
$value = $_POST['search'];

	$sql = "SELECT s.student_id,s.first_name,s.last_name,s.fathername,r.marks,r.percentage,r.grade from std_result r JOIN stdprofile s ON 
																		s.student_id = r.student_id   where (s.student_id like '%$value%' or s.first_name like '%$value%' or s.last_name like '%$value%')";
	$result = mysqli_query($conn,$sql);

		if(mysqli_num_rows($result)> 0){

			$output .= '<h4 align="center"> Search Result:</h4>';
			$output .= '<div class="table-responsive">
							<table class="table table-bordered">
									<tr>
											<td>Student Roll Number:</td>
											<td>Full Name:</td>
											<td>Father Name:</td>
											<td>Marks:</td>
											<td>Percentage:</td>
											
											
											
											<td>Grade:</td>
											



										</tr>';

										while ($row = Mysqli_fetch_array($result)) {
											
												$output .= '	
															<tr>
															<td>'.$row['student_id'].'</td>
															<td>'.$row['first_name'].'   '.$row['last_name'].'</td>
															<td>'.$row['fathername'].'</td>
															<td>'.$row['marks'].'</td>

															<td>'.$row['percentage'].'</td>
															
															
															<td>'.$row['grade'].'</td>
															
															
	
															</tr>
															';

												
										}
											echo $output;


			


		}
		else{
			echo "Data Not Found";
		}

?>


