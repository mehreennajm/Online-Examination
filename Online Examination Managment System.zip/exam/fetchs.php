<?php
		
session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");

$output = '';

if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
$value = $_POST['search'];

	$sql = "SELECT * FROM subjects where (subname like '%$value%' or s_id like '%$value%')";
	$result = mysqli_query($conn,$sql);

		if(mysqli_num_rows($result)> 0){

			$output .= '<h4 align="center"> Search Result:</h4>';
			$output .= '<div class="table-responsive">
							<table class="table table-bordered">
									<tr>
											<td>Subject ID:</td>
											<td>Subject Name:</td>
											


										</tr>';

										while ($row = Mysqli_fetch_array($result)) {
											
												$output .= '	
															<tr>
															<td>'.$row['s_id'].'</td>
															<td>'.$row['subname'].'</td>
															
															
	
															</tr>
															';

												
										}
											echo $output;


			


		}
		else{
			echo "Data Not Found";
		}

?>


