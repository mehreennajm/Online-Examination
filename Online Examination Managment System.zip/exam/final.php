<?php 
include 'database.php';

session_start();



?>






<!doctype html>

<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <style type="text/css">
             li{
                list-style-type: none;
                padding: 2%;


            }
        </style>
        <link rel="icon" href="icon/favicon.ico">
    <link rel="shortcut icon" href="icon/favicon.ico" />   
    	
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Quiz</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/roboto-webfont.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
        <link href="fileinput/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="fileinput/themes/explorer-fa/theme.css" media="all" rel="stylesheet" type="text/css"/>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="fileinput/js/plugins/sortable.js" type="text/javascript"></script>
    <script src="fileinput/js/fileinput.js" type="text/javascript"></script>
    <script src="fileinput/js/locales/fr.js" type="text/javascript"></script>
    <script src="fileinput/js/locales/es.js" type="text/javascript"></script>
    <script src="fileinput/themes/explorer-fa/theme.js" type="text/javascript"></script>
    <script src="fileinput/themes/fa/theme.js" type="text/javascript"></script>

    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <!-- Sections -->
        

        
        <!--Home page style-->
      

                                     
                                   <div class="col-md-5 col-sm-5 col-md-offset-4 col-sm-offset-4">
    <div class="page-header">
        <h2 style="text-align: center;">Congratulations! You are Done!
           
        </h2>
    </div>
   
    
   <form action="student_score.php" method="post">

   <div class="form-group">

    Please Enter your ID Number : <input type="text" name="student_id" placeholder="Please Enter Your ID..." class="form-control" value="">
    
  </div>

  <div class="form-group">
                    Your Final Score is : <input type="text" value="<?php echo $_SESSION['score']; ?>" disabled class="form-control" >
  </div>
    
     


  <div class="form-group">   <input type="submit" name="submit" value="Submit" class="btn btn-success ">
    <a href="logout.php"   class="btn btn-warning ">Sign Out</a></div>

   

    
    

        </div>


        </form></div>



		<div class="scrollup">
			<a href="#"><i class="fa fa-chevron-up"></i></a>
		</div>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/modernizr.js"></script>
        <script src="assets/js/main.js"></script>




</body>
</html>
