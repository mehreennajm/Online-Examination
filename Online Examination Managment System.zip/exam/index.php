<?php   
$msg ="";
session_start();
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}

?>
<?php 

if(isset($_POST['submit'])) 
    {     
        
        $name = $_POST["username"]; 
        $password = $_POST["password"]; 
        $sql= "SELECT *  FROM stdprofile WHERE email = '".$name."' and  password = '".$password."' ";

        $result1 = mysqli_query($conn,$sql);

        while ($row = mysqli_fetch_array($result1)) {
                if(isset($_POST['remember'])=="on"){
                    setcookie('user',$name,time()+3600);
                    setcookie('pass',$password,time()+3600);}
            $_SESSION["login"] = true; 
            $_SESSION["username"] = $name; 
            $_SESSION["password"] = $password; 

            if($row['type'] == 'admin'){
                header("location:panel.php");
            }

            if($row['type'] == 'student'){
                header("location:exam.php");
            } 

             else
                    {
                    $msg= "<div  class='alert alert-danger'><strong>Incorrect Username or Password!</strong></div>";
           
                    }
     
        }


       
        
        

}








?>









<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
          <link rel="icon" href="icon/favicon.ico">
    <link rel="shortcut icon" href="icon/favicon.ico" />  
    	
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Student Examination System</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/roboto-webfont.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <!-- Sections -->
        

        
        <!--Home page style-->
        <header id="home" class="home">
            <div class="overlay-fluid-block">
                <div class="container text-center">
                    <div class="row">
                        <div class="home-wrapper">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="home-content" >
                                     <p> <?php  echo $msg; ?></p>
  

                                    <h1>Universities Online Examination System</h1>
                                    <p>Online Examination assesses candidates and students by conducting online tests. It also enables educational institutes to conduct test and have automated checking of answers based on the response by the candidates or students.
Through this system we allow faculties and the other institutes to create their own tests.</p>

                                    <div class="row">
                                        <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
                                            <div class="home-contact">
                                                
                                                    <form action="index.php" method="post">
  <div class="form-group">
   
    <input type="email" class="form-control" name="username" id="exampleInputEmail1" placeholder="Email" required value="<?php 
if(isset($_COOKIE['user'])){
  echo $_COOKIE['user'];}

?>">
  </div>
  <div class="form-group">
   
    <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password" required value="<?php 
if(isset($_COOKIE['pass'])){
  echo $_COOKIE['pass'];}

?>">
  </div>
 
  <div class="checkbox">
    <label style="color: white;">
      <input type="checkbox"  name="remember"> Check me out
    </label>
  </div>
  <input type="submit" class="btn btn-success " value="Sign In" name="submit"></input>
  <a href="signup.php" class="btn btn-primary">Sign Up As Student</a><br>
  
</form>


                                                </div><!-- /input-group -->


                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>			
            </div>
        </header>

      <section id="social" class="social">
            <div class="container">
                <!-- Example row of columns -->
                <div class="row">
                    <div class="social-wrapper">
                        <div class="col-md-6">
                            <div class="social-icon">
                                <a href="https://www.facebook.com" target="_blank"><i class="fa fa-facebook"></i></a>
                                <a href="https://www.twitter.com" target="_blank" ><i class="fa fa-twitter"></i></a>
                                <a href="https://www.googleplus.com" target="_blank"><i class="fa fa-google-plus"></i></a>
                                <a href="https://wwww.linkedin.com" target="_blank"><i class="fa fa-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="social-contact">
                                <a href="#"><i class="fa fa-phone"></i>+93783873895</a>
                                <a href="#"><i class="fa fa-envelope"></i>mehreenhushmand2016@gmail.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- /container -->       
        </section>
		
		<div class="scrollup">
			<a href="#"><i class="fa fa-chevron-up"></i></a>
		</div>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/modernizr.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>

