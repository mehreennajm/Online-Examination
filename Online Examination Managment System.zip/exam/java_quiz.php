<?php


session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");


?>

<?php 
        $dbhost = 'localhost';
        $dbuser = 'root';
        $dbpass = '';
        $conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");
        if(! $conn )
    {
                die('Could not connect: ' . mysqli_error());
                }




$test="SELECT question,ans1,ans2,ans3,ans4,correct from questions";
$result  = mysqli_query($conn,$test);




?>

<!DOCTYPE html>
<html>
<head>
      <link rel="icon" href="icon/favicon.ico">
    <link rel="shortcut icon" href="icon/favicon.ico" />   
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Quiz</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
   
   
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="" method="post">
                    <?php  foreach($result as $row){ ?>
                                  <?php  $ans_array = array($row->ans1,$row->ans2,$row->ans3);
                                     shuffle($ans_array);    ?>

                                            <p><?=$row->id ?>.<?=$row->question ?></p>








                   <?php  }
                    ?>
                      

                    <input type="submit" name="submit" value="Submit" class="btn btn-success">
                    }
                </form>
            </div>
        </div>
    </div>










<script src="assets/js/vendor/bootstrap.min.js"></script>
</body>
</html> 