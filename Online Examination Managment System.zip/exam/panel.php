<?php


session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");


?>

<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"examination");
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}




$test=("SELECT *  from stdprofile");
$result=mysqli_query($conn,$test);
$name=mysqli_fetch_assoc($result);


?>

<!DOCTYPE html>
<html>
<head>
	  <link rel="icon" href="icon/favicon.ico">
    <link rel="shortcut icon" href="icon/favicon.ico" />  
	<script src="assets/js/sidebar.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/sidebar.css">
 <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>PANEL SETTINGS</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="fileinput/themes/explorer-fa/theme.css" media="all" rel="stylesheet" type="text/css"/>
    <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
  </head>
<body>

	<nav class="navbar navbar-inverse sidebar" role="navigation">
    <div class="container-fluid">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="#">Dashboard</a>
		</div>
		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
			<ul class="nav navbar-nav">
				
				<li class="dropdown">
					<a href="panel.php" class="dropdown-toggle" data-toggle="dropdown">Students Profile <span class="caret"></span><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-cog"></span></a>
					<ul class="dropdown-menu forAnimate" role="menu">
						<li><a href="panel.php">Display Students Info</a></li>
						<li><a href="signup.php">Add student</a></li>
						
						
					</ul>
				</li>
				
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Questions <span class="caret"></span><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-cog"></span></a>
					<ul class="dropdown-menu forAnimate" role="menu">
						<li><a href="questions.php">Display Questions</a></li>
						<li><a href="add_qu.php">Add question</a></li>
						
						
					</ul>
				</li>

				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Answers <span class="caret"></span><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-cog"></span></a>
					<ul class="dropdown-menu forAnimate" role="menu">
						<li><a href="Answers.php">Display Answers</a></li>
						<li><a href="add_a.php">Add Answer</a></li>
						
						
					</ul>
				</li>

				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Subjects <span class="caret"></span><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-cog"></span></a>
					<ul class="dropdown-menu forAnimate" role="menu">
						<li><a href="display_subjects.php">Display Subjects</a></li>
						<li><a href="add_sub.php">Add Subject</a></li>
						
						
					</ul>
				</li>


				<li class="dropdown">
					<a href="display_result.php" class="dropdown-toggle" >Results <span class="caret"></span><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-cog"></span></a>

					
				</li>

			</ul>
			<div style="margin-top: 25%;margin-left: 25%;">
		<form action="logout.php" method="post"><input type="submit" name="logout" value="Sign Out" class="btn btn-success">
			</form></div>
			
		</div>
		
	</div>
</nav>





<!-- Display students profile here -->
<div class="main">
	<div class='form-group'>
        		<div class='input-group'>
        		<span class='input-group-addon'>Search</span>
        		<form action="" method="post">
          <input type='text' class='form-control' placeholder='Search Student By Name...' name='search-text' id='search-text'>
       </form>
        
     </div></div>
     <br><br>
      <div id='resultt'></div>

	<?php echo "

<div>
 
        
      
</div>





<div class='table-responsive'>
<table class='table table-hover'><tr><th>ID:</th><th>Full Name:</th><th>DOB:</th><th>Gender
<th>Address</th><th>Phone#:</th><th>Tazkira#:</th><th>email:</th><th>password:</th><th>User Type:</th><th>Urgent Files</th><th>Delete:</th><th>Edit:</th>

</tr>";
do{
	
	echo "<tr class='success'>";
	echo "<td class='success'>".$name['student_id']."</td>";
	echo "<td>".$name['first_name'].'   '.$name['last_name']."</td>";
	echo "<td>".$name['dob']."</td>";
	echo "<td>".$name['gender']."</td>";
	echo "<td>".$name['address']."</td>";
	echo "<td>".$name['phone']."</td>";
	echo "<td>".$name['tazkira']."</td>";
	echo "<td>".$name['email']."</td>";
	echo "<td>".$name['password']."</td>";
	echo "<td>".$name['type']."</td>";
	echo "<td>".$name['urgentFiles']."</td>";
	echo "<td>"."<a href='delete_student.php?id=".$name['student_id']."'><img  style='margin-left:30%;' src='icon/delete.png' width='16' height='16' />"."</a>"."</td>";
	echo "<td>"."<a href='edit_std.php?id=".$name['student_id']."'><img  style='margin-left:30%;' src='icon/edit.png' width='16' height='16' />"."</a>"."</td>";
	

	
	
}while($name=mysqli_fetch_assoc($result));
echo "</table></div></div></div></body></html>";

?>


	

</div>


















<script src="assets/js/vendor/bootstrap.min.js"></script>
<script>
	$(document).ready(function(){
					$('#search-text').keyup(function(){

											var txt = $(this).val();
											if(txt != ''){
																$.ajax({



															url:'fetch.php',
															method:'post',
															data:{search:txt},
															dataType:'text',
															success: function(data){
																$('#resultt').html(data);
															}






																});

													




											}


											else{

														$('#resultt').html('');


											}

					});

	});
</script>
</body>
</html>