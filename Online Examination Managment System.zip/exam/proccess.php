<?php
	include 'database.php';


	if(!isset($_SESSION['score'])){
		$_SESSION['score'] =0;
	}


	if($_POST){
		$number = $_POST['number'];
		$selected_choice = $_POST['choice'];
		$next = $number+1;

		//get the correct choice

		$query= "SELECT * from `answers` where question_id = $number  and is_correct = 1";



		//get result

		$result = $mysqli->query($query) or die($mysqli->error.__LINE__);


		//get row 
		$row = $result->fetch_assoc();


		//set correct choice
		$correct_choice = $row['id'];


		//get total questions..................................................................................
		$query = "SELECT * FROM 	`questions`";
		$results = $mysqli->query($query);
		$total = $results->num_rows;




		//compare the selected choice feat correct chioce 
		if($selected_choice == $correct_choice){
			$_SESSION['score']++;

		}


		
		if($number == $total){
			header("location:final.php");
			exit();
		}


		else{

			header("location:start_quiz.php?n=".$next);
		}

	}





?>