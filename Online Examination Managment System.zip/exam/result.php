<?php


session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");


?>



<!DOCTYPE html>
<html>
<head>
	  <link rel="icon" href="icon/favicon.ico">
    <link rel="shortcut icon" href="icon/favicon.ico" />  
	<script src="assets/js/sidebar.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/sidebar.css">
 <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Results</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="fileinput/themes/explorer-fa/theme.css" media="all" rel="stylesheet" type="text/css"/>
    <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
  </head>
<body>





<!-- Display students profile here -->
<div class="main">
	<div class="col-md-9 col-sm-9 col-md-offset-1 col-sm-offset-4">
	<div class='form-group'>
        		<div class='input-group'>
        		<span class='input-group-addon'>Search</span>
        		<form action="" method="post">
          <input type='text' class='form-control' placeholder='Search Student By Name...' name='search-text' id='search-text'>
       </form>
        
     </div></div>
     <br><br>
      <div id='resultt'></div>


	

</div>


















<script src="assets/js/vendor/bootstrap.min.js"></script>
<script>
	$(document).ready(function(){
					$('#search-text').keyup(function(){

											var txt = $(this).val();
											if(txt != ''){
																$.ajax({



															url:'fetchr.php',
															method:'post',
															data:{search:txt},
															dataType:'text',
															success: function(data){
																$('#resultt').html(data);
															}






																});

													




											}


											else{

														$('#resultt').html('');


											}

					});

	});
</script>
</body>
</html>