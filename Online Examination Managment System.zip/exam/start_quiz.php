<?php


session_start();


include 'database.php';



?>

<?php


            //get total questions
        $query = "SELECT * FROM  `questions`";
        $results = $mysqli->query($query);
        $total = $results->num_rows;




    //set question number
            $number = (int) $_GET['n'];

            $query = "SELECT * FROM `questions` 
                        where id = $number";

            //get result 
                $result  = $mysqli->query($query) or die($mysqli->error.__LINE__);

                $q = $result->fetch_assoc();

        //get total questions 


                $query = "SELECT * FROM     `questions`";
                $results = $mysqli->query($query) or die($mysqli->error.__LINE__);
                $t = $results->num_rows;





    //set answer number
            $number = (int) $_GET['n'];

            $query = "SELECT * FROM `answers` 
                        where question_id = $number";

            //get result 
               $choices = $mysqli->query($query) or die($mysqli->error.__LINE__);

               $total = $choices->num_rows;


               include 'proccess.php';

                 




?>










<!doctype html>

<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <style type="text/css">
             li{
                list-style-type: none;
                padding: 2%;


            }
        </style>
        <link rel="icon" href="icon/favicon.ico">
    <link rel="shortcut icon" href="icon/favicon.ico" />   
    	
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Quiz</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/roboto-webfont.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
        <link href="fileinput/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css"/>
    <link href="fileinput/themes/explorer-fa/theme.css" media="all" rel="stylesheet" type="text/css"/>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="fileinput/js/plugins/sortable.js" type="text/javascript"></script>
    <script src="fileinput/js/fileinput.js" type="text/javascript"></script>
    <script src="fileinput/js/locales/fr.js" type="text/javascript"></script>
    <script src="fileinput/js/locales/es.js" type="text/javascript"></script>
    <script src="fileinput/themes/explorer-fa/theme.js" type="text/javascript"></script>
    <script src="fileinput/themes/fa/theme.js" type="text/javascript"></script>

    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <!-- Sections -->
        

        
        <!--Home page style-->
      

                                     
                                   <div class="col-md-5 col-sm-5 col-md-offset-4 col-sm-offset-4">

                                     <div class="page-header">
       <div style="font-weight: bold;font-size: 20px;" id='quiz_time_left'></div>
    </div>
    <div class="page-header">
        <h2 style="text-align: center;"><?php echo $q['id']; ?> 0f <?php echo $t; ?> Questions
           
        </h2>
    </div>
   
    
    <form action="" method="post" name="quiz">
   

   <div class="form-group">
    <?php echo $q['question']; ?>
  </div>

  <div class="form-group">
    <?php while($row = $choices->fetch_assoc()): ?>
    <li><input type="radio" name="choice"  value="<?php  echo $row['id']; ?>"><?php echo $row['text']; ?></li>
       <?php endwhile; ?>
  </div>


  <div class="form-group">
    <input type="submit" value="Submit" name="submit" class="btn btn-success">
     <input type="hidden" value="<?php echo $number; ?>" name="number" class="btn btn-success">
  </div>
    
    

        </div>

        



		<div class="scrollup">
			<a href="#"><i class="fa fa-chevron-up"></i></a>
		</div>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/modernizr.js"></script>
        <script src="assets/js/main.js"></script>

        <script>
            var total_seconds = 60*1;
            var c_minutes = parseInt(total_seconds/60);
            var c_seconds = parseInt(total_seconds%60);
            function Checktime(){
                document.getElementById("quiz_time_left").innerHTML
                ='Time Left:     ' +c_minutes+ 'Minutes:    '+c_seconds+'     Seconds';
                if(total_seconds <=0){
                    setTimeout = ('document.quiz.submit()',1);
                }

                else{
                    total_seconds = total_seconds-1;
                    c_minutes = parseInt(total_seconds/60);
                    c_seconds = parseInt(total_seconds%60);
                    setTimeout("Checktime()",1000);

                }
            }
            setTimeout("Checktime()",1000);

        </script>




</body>
</html>
