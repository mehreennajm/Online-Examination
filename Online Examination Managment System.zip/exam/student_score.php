<?php

include'database.php';

session_start();
$r= $_SESSION['password'];
$e= $_SESSION['username'];

if(isset($r,$e)){
echo "";

}
else
header("location:index.php?notallowed");


?>

<?php 

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn =  mysqli_connect($dbhost, $dbuser, $dbpass,"examination");
if(! $conn )
{
  die('Could not connect: ' .  mysqli_error());
}

if(isset($_POST['submit'])){
   $grade = '';
    $student_id = $_POST['student_id'];
    $score= $_SESSION['score'];
    $percentage = ($score*100)/12;
    if($percentage<=100.00 and $percentage>= 90.00){
    	$grade = 'A';
    }

    elseif($percentage<=90.00 and $percentage>=85.00){
    	$grade = 'B';
    }
     elseif($percentage<=75.00 and $percentage>=80.00){
    	$grade = 'C';
    }

     elseif($percentage<=65.00 and $percentage>=75.00){
    	$grade = 'D';
    }
     elseif($percentage<=60.00 and $percentage>=65.00){
    	$grade = 'Fail';
    }
    $sql = "INSERT into std_result(id,marks,percentage,grade,student_id) VALUES('NULL','$score','$percentage','$grade','$student_id')";
    $r =   mysqli_query($conn,$sql);
    if($r){
    			header("location:index.php");
         }

         else{
            header("location:final.php?submit=failed");
         }

   }

   ?>